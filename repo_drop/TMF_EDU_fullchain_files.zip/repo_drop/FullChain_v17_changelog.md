# TMF Full Chain Analyser — changelog v1.5 → v1.7

Scope, limitations and the full assumption register live in `FullChain_audit.md`.
Every change below is marked in the source with a `[FIX v1.6]` or `[FIX v1.7]`
comment stating what the old code did and why it was wrong.

Verification harness: `FullChain_verify_v17.js` (headless Chromium). Results
quoted here are from that script.

---

## v1.7 — real pressure, closed cycle, dead controls wired

### A. IAPWS property layer replaces the linear superheat approximation

v1.6 and earlier had **no pressure anywhere in the model**. Superheated steam was
approximated as `h = h_g + 2.1·ΔT`, entropy as `s = s_g + c_p·ln(T₂/T₁)`, and the
feed pump saw a **step-function** ΔP — 40 bar above `T_boil = 180 °C`, 20 bar
below, so the pump work jumped discontinuously as the boiler slider crossed 180.

Replaced with the property layer from the separately validated
`TMF_Rankine_Simulator_v32`:

- `SAT` — 30-point saturated-water table plus the Wagner saturation-pressure
  equation and liquid specific volume `v_f`
- `SH_TABLE` — superheated-steam `h` and `s` at 1…200 bar
- `tSatFromP` — inverse Wagner, memoised bisection
- `superheatProps(T, P_bar)` — bilinear interpolation
- `isobarSH` — a real isobar for the T-s plots instead of a straight chord

Spot checks against published IAPWS values:

| Quantity | v1.7 | Published |
|---|---|---|
| h(100 bar, 500 °C) | 3375.1 kJ/kg | 3375.1 |
| s(100 bar, 500 °C) | 6.5993 kJ/kgK | 6.5994 |
| h(40 bar, 400 °C) | 3214.4 kJ/kg | 3214.5 |
| P_sat(300 °C) | 85.88 bar | 85.88 |
| P_sat(100 °C) | 1.0142 bar | 1.0142 |

Pump work is now continuous across the old discontinuity: 1.329 → 1.360 → 1.392
kJ/kg at T_boil = 179/180/181 °C.

### B. The cycle is now closed

`calcBoiler()` used a hard-coded feedwater enthalpy of **80 kJ/kg** while the
pump actually delivered ≈200 kJ/kg. The boiler duty and the cycle therefore
disagreed by ~120 kJ/kg in the denominator of

```
m_steam = Q_avail / (h₁ − h_fw)
```

and the steam mass flow — which multiplies straight into `W_mech`, `P_elec`,
`η_total` and `EROI` — was systematically wrong. Feedwater is now the pump outlet
`h₄`. Residual: `Q_avail − m_steam·(h₁ − h₄) = 0.000 kW`.

### C. One shared cycle core

v1.6 carried **two independent cycle implementations**: `calcBoiler`+`calcTurbine`
for the analysis tabs, and `animCalcCycle()` for the animation tab. They had
already drifted apart — different superheat approximation, different pump work.
That divergence is how the v1.5 entropy sign error (§v1.6-F) survived in one of
them while the plots were driven by the other.

Both now call `rankineCycle()`. Agreement verified to 1e-9.

### D. Isentropic exit may be superheated

When `s₁ > s_g(T_cond)` the isentropic end state is superheated and its enthalpy
lies **above** `h_g`. Clamping the quality to 1 understates `h₂ₛ`, overstates the
turbine work, and lets `η_classic` exceed its own Carnot bound. The dome is now
extended with a constant-`c_p` ideal-gas leg (`CP_VAP = 1.95` kJ/kgK, used only
at condenser pressure).

### E. Carnot reference is the entropic mean temperature of heat addition

`T_sat(boiler)` is **not** an upper bound once the steam is superheated. The
reference is now

```
T̄ = (h₁ − h₄)/(s₁ − s₄),    η_Carnot = 1 − T_cond/T̄
```

Sweep over T_boil 100–340 °C × T_sh (T_boil+20)–560 °C × T_cond 20–90 °C × η_is
{0.60, 0.75, 0.85, 0.95}: **13 316 cases, 0 Carnot violations** (8 165 wet
exhaust, 5 151 dry). The gap between η_Carnot(T̄) = 39.5 % and η_Carnot(T_sh) =
57.8 % at defaults is the non-isothermal heat-input loss, now displayed.

### F. Δη is scaled by κ_turbine, not κ_peak

`κ_peak` is essentially always `κ_boiler` (1.72 vs 1.15 at defaults), i.e. it is
dominated by the boiler's latent heat — while the entire σ_μ argument is about
the **turbine inlet**. Set `kap_drive = kap_peak` in the source to restore the
old behaviour.

### G. Excess-air λ was counted twice in the flame temperature

`m_fg` already contains it (`m_fg = m_fuel·(1 + λ·6.5)`); the old code divided by
λ a second time, so raising the excess air cooled the flame roughly twice as fast
as it should. The `0.95` fudge also sat in the denominator, where it **raised**
the temperature — the opposite of the loss it was named after. It is now an
explicit radiative-loss factor in the numerator, and the ceiling was raised from
1600 to 1900 °C because the corrected nominal case (1462 °C) would otherwise have
been clipped.

λ = 1.0 → 1712 °C, λ = 1.2 → 1462 °C, λ = 2.5 → 756 °C.

### H. Three dead sliders wired

`eta_gen`, `cos_phi` and `slip` changed nothing. The loss split was hard-coded as
fixed fractions of the mechanical input, so generator efficiency was pinned at
94.5 % wherever the user put the slider, and cos φ affected nothing at all.

Now: the rated efficiency sets the **total loss at the rated point**, split into
load-dependent (copper) and load-independent (iron + windage + stray) parts.
Copper loss scales as `(P/P_nom/cos φ)²`, because a poorer power factor means
more current for the same real power. `slip` became the governor droop
coefficient it was always labelled as — its range, 0.005–0.08, is exactly the
usual 0.5–8 % droop range.

### I. Saturation-curve panel used an ambient-temperature formula

The pressure/saturation chart was drawn with the Magnus–Tetens vapour-pressure
fit, which is only usable to roughly 50 °C. At the default 300 °C it returned
**1052 bar** against a true 85.9 bar, and the marker sat pinned to the top of the
frame. Now Wagner, so the chart agrees with the pressure the cycle uses.

### J. Two charts were not connected to the model

- **κ(μ) "entropy birth locus"** was a hard-coded shape — the array
  `[0.8, 3.5, 1.2, 0.6]` plus a sine bump — that did not respond to any slider.
  It now plots the model's actual κ per station and marks which one drives Δη.
- **η vs σ_μ** still used the pre-v1.7 subtractive formula, plotted on a 0–100 %
  axis where a few-percent effect is about 2 px tall. It looked like a horizontal
  line under every setting. Now the current model, on an axis zoomed to its range.

### Nominal operating point after v1.7

| | |
|---|---|
| P_boiler / P_cond | 85.88 / 0.096 bar |
| h₁ / s₁ | 3341.7 kJ/kg / 6.6209 kJ/kgK |
| h₄ (feedwater) | 200.1 kJ/kg |
| w_pump | 11.75 kJ/kg |
| m_steam | 225 g/s |
| x₂ (exhaust quality) | 0.889 |
| η_classic / η_TMF | 32.27 % / 32.14 % |
| η_Carnot(T̄) / η_Carnot(T_sh) | 39.50 % / 57.76 % |
| T̄ heat input | 252.8 °C |
| W_mech → P_elec | 227.6 → 206.9 kW |
| η_total | 22.45 % |

---

## v1.6 — 14 defect fixes

| # | Defect | Effect |
|---|---|---|
| 1 | **Async race in the data logger.** `dlBuildRecord()` is async because `crypto.subtle.digest()` is; the read-modify-write of `DL._prevHash` therefore spanned an `await` boundary | Two overlapping writers read the **same** `prev_hash` and the SHA-256 chain forked. Reachable via the 1 s critical interval, WebSocket injection, or `dlStart()` racing its own timer. Reproduced: 40 concurrent writes broke the chain at record 2 and produced 3 distinct hashes out of 40. Fixed with a serialised write queue — same test now gives 0 broken links, 32 unique hashes, 8 dropped by a reported back-pressure valve |
| 2 | Branch diagram hard-capped at `Math.min(N,8)` while the slider goes to 10 | N = 9 and N = 10 drew identically to N = 8; the picture silently disagreed with the maths and with its own node-status badge |
| 3 | **Pythagorean-triple "resonance"** scored `d_i/d₀` against the a/c and b/c ratios of Pythagorean triples | Those ratios form an arbitrary dense set in (0.2, 0.98), so the distance was always small, the score always high, and the derived η pinned at 0.9996–1.0000 — a constant printed to four decimals. It also conflated Pythagorean *triples* (number theory) with Pythagorean *tuning* (acoustics). Replaced with the junction reflection coefficient `R = (A₀−ΣA_i)/(A₀+ΣA_i)`, Arnold-tongue harmonic locking, and a Rayleigh index — see `FullChain_audit.md` §2.5 |
| 4 | `switchTab()` looped only to `panel8` | **Tab 10 (DATALOG) showed a blank content area**, including from the header widget |
| 5 | Raw newline inside a string literal in the NDJSON/CSV export | A parse error that disabled the **entire script** in the affected copy |
| 6 | Superheat entropy **sign error** in `calcBoiler` (`s_g − 0.002·ΔT`) while every plot used `+0.0018·ΔT` | Sat upstream of `calcTurbine`, so exhaust quality came out far too wet and the blade-erosion warning fired on healthy states. Magnitude was also ~40 % low |
| 7 | Exhaust quality reported the **isentropic** value | The real exhaust is drier (h₂ > h₂ₛ); 0.749 CRITICAL was reported where the true value was 0.835 WARN |
| 8 | Chaos history threshold bands shifted one band up | Green covered 0.2–0.5 and yellow 0.5–0.8 — the exact opposite of the legend. K = 0.45 drew inside the green zone while the gauge beside it read WARNING |
| 9 | `dlDrawMiniChart(..., yMax = null)` → `Math.min(null, v) = 0` | The P_electric chart rendered as a flat line along the axis |
| 10 | `validateParams()` clamp wrote to `sl-…`/`lv-…` IDs; `addSlider()` creates `s-…`/`v-…` | The slider handle stayed at the rejected value while the model used the clamped one |
| 11 | `Z_rad` went negative when `T_flame ≤ T_wall` | Negative percentages in the impedance breakdown that did not sum to 100 % |
| 12 | EROI used **thermal** output and a 0.50 upstream factor | Reduced algebraically to `2·η_comb·(LHV_wet/LHV_dry)` — bounded above by ~1.6 regardless of boiler, turbine or generator, so the metric could not respond to the plant. Reformulated as electrical output ÷ invested energy with a documented 0.03 factor |
| 13 | `ch.turb.sig_mu` — `calcChaos()` has no `.turb` field | TypeError; the whole CHAOS sidebar render aborted |
| 14 | `ch.bearing_df` did not exist either | Same aborted render |
